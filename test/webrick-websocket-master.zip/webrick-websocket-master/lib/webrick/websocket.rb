require 'webrick/websocket/version'
require 'webrick'
require 'webrick/httprequest_patch'
require 'webrick/websocket/server'

module WEBrick
  module Websocket

  end
end
