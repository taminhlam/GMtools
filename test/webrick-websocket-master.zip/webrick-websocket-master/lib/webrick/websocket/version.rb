module WEBrick
  module Websocket
    VERSION = '0.0.4'
  end
end
